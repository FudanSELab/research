package preserveOther.domain;


public class PreserveInformation {
    //车次、发车日期、出发地、目的地、乘车人、乘车人对应的座位等级
}
