package foodsearch.domain;

public class QueryFoodStoresInfo {

    String stationId;

    public QueryFoodStoresInfo(){

    }

    public String getStationId() {
        return stationId;
    }

    public void setStationId(String stationId) {
        this.stationId = stationId;
    }

}
