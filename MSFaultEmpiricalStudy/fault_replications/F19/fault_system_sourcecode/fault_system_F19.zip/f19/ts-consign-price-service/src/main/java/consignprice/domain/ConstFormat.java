package consignprice.domain;

public class ConstFormat {
    public static final int DEFAULT_US_FORMAT = 0;
    public static final int FRENCH_FORMAT = 1;
    public static final int GERMAN_FORMAT = 2;
}
