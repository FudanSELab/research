package execute.domain;

public class TicketExecuteInfo {

    private String orderId;

    public TicketExecuteInfo() {
        //Default Constructor
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
