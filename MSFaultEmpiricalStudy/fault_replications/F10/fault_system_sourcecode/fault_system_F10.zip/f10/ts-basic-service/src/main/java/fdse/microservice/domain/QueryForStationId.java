package fdse.microservice.domain;

/**
 * Created by Wenyi on 2017/6/15.
 */
public class QueryForStationId {

    private String name;

    public QueryForStationId(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
