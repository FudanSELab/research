package foodsearch.domain;

public class QueryTrainFoodInfo {

    public String getTripId() {
        return tripId;
    }

    public void setTripId(String tripId) {
        this.tripId = tripId;
    }

    String tripId;

    public QueryTrainFoodInfo(){

    }
}
