

web go:
https://github.com/hoisie/web
https://github.com/astaxie/beego


url:
http://localhost:16102/test?cal=50


copy:
docker cp web.go:/app/ /host/path/target